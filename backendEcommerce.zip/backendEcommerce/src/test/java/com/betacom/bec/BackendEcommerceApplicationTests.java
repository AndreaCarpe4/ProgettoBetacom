package com.betacom.bec;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackendEcommerceApplicationTests {

	@Test
	void contextLoads() {
	}

}
