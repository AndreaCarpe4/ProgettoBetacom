package com.betacom.fe;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FrontendEcommerceApplicationTests {

	@Test
	void contextLoads() {
	}

}
